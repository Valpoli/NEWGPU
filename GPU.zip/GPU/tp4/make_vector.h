#pragma once

#include <vector>

// create a vector of a given size with random integers between -100 and +100
std::vector<int> make_vector(int size);
